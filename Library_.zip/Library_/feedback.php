<?php
  include "navbar.php";
  include "connection.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Feedback</title>
	
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 

    <style type="text/css">
    <link rel="icon" href="images/library.png">
    	body
    	{
    		background-color: white;
    		background-repeat: no-repeat;
    	}
    	.wrapper
    	{
    		padding: 10px;
    		margin: -20px auto;
    		width:900px;
    		height: 600px;
    		background-color: transparent;
    		opacity: .8;
    		color: white;
    	}
    	.form-control
    	{
    		height: 70px;
    		width: 30%;
    	}
    	.scroll
    	{
    		width: 100%;
    		height: 300px;
    		overflow: auto;
    	}

    </style>
   
</head>
<body>

	
	
<h2 style="color: black; font-size: 30px; font-weight: bold; ">Feedback</h2>
	<?php

		
			$res=mysqli_query($db,"SELECT comment FROM `comments`;");

		echo "<table class='table table-bordered table-hover' >";
			echo "<tr style='background-color: #16d1d7; color: black; padding-right:60px;'>";
				//Table header
				echo "<th>"; echo "Comment";	echo "</th>";
				
			echo "</tr>";	

			while($row=mysqli_fetch_assoc($res))
			{
				echo "<tr>";
				
				echo "<td>"; echo $row['comment']; echo "</td>";

				echo "</tr>";
			}
		echo "</table>";
		

	?>
	</div>
	</div>
	
</body>
</html>
