<?php
  session_start();
  include('connection.php')
?>
<html>
<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>


      <nav class="navbar navbar-inverse" style="background-color: #F4D101; border-color: #F4D101;">
      <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand active" style="color: black;">ONLINE LIBRARY MANAGEMENT SYSTEM</a>
          </div>
          <ul class="nav navbar-nav" style="color: black;">
            <li><a href="index.php" style="color: black;">HOME</a></li>
            <li><a href="books.php" style="color: black;">BOOKS</a></li>
            <li><a href="feedback.php" style="color: black;">FEEDBACK</a></li>
          </ul>
          <?php
            if(isset($_SESSION['login_user']))
            {

          ?>
                <ul class="nav navbar-nav">
                  <li><a href="profile.php" style="color: black;">PROFILE</a></li>
                  <li><a href="fine.php" style="color: black;">FINES</a></li>

                </ul>
                <ul class="nav navbar-nav navbar-right">
   <li><a href="announcement.php"><i class="material-icons md-48" style="color: black;">announcement</i></a></li>

                <ul class="nav navbar-nav navbar-right">
                  <li><a href="">
                    <div style="color: black;">
                      <?php
                        echo "<img class='img-circle profile_img' height=30 width=30 src='images/".$_SESSION['pic']."'>";
                        echo " ".$_SESSION['login_user']; 
                      ?>
                    </div>
                  </a></li>
                  <li><a href="logout.php" style="color: black;"><span class="glyphicon glyphicon-log-out"> LOGOUT</span></a></li>
                </ul>
              <?php
            }
            else
            {   ?>
              <ul class="nav navbar-nav navbar-right">

                <li><a href="../login.php" style="color: black;"><span class="glyphicon glyphicon-log-in"> LOGIN</span></a></li>
                
                <li><a href="registration.php" style="color: black;"><span class="glyphicon glyphicon-user"> SIGN UP</span></a></li>
              </ul>
                <?php
            }
          ?>

      </div>
    </nav>

    <?php
      if(isset($_SESSION['login_user']))
      {
        $day=0;

        $exp='<p style="color:yellow; background-color:red;">EXPIRED</p>';
        $res= mysqli_query($db,"SELECT * FROM `issue_book` where username ='$_SESSION[login_user]' and approve ='$exp' ;");
      
      while($row=mysqli_fetch_assoc($res))
      {
        $d= strtotime($row['return']);
        $c= strtotime(date("Y-m-d"));
        $diff= $c-$d;

        if($diff>=0)
        {
          $day= $day+floor($diff/(60*60*24)); 
        } //Days
        
      }
      $_SESSION['fine']=$day*.10;
    }
    ?>
     
</body>
</html>