<?php
  include "navbar.php";
  include "connection.php";
?>

<!DOCTYPE html>
<html>
<head>
  <title>Annaouncement</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
    <style type="text/css">
      body
      {
        background-color: white;
        background-repeat: no-repeat;
      }
      .wrapper
      {
        padding: 10px;
        margin: -20px auto;
        width:900px;
        height: 600px;
        background-color: transparent;
        opacity: .8;
        color: white;
      }
      .form-control
      {
        height: 70px;
        width: 30%;
      }
      .scroll
      {
        width: 100%;
        height: 300px;
        overflow: auto;
      }

    </style>
</head>
<body>
          <div class="panel-heading">
            <div class="row">
                <h3 class="center-block ml-4 mt-5 mb-3" style="text-align: center;">Announcements</h3>
            </div>
          </div>
          <table class="table table-bordered">


            <thead>
                <tr>
                    
                         <th style="color: green;">Announcement</th>

                          
                </tr>
          </thead>

           <?php

          $sql2 = "SELECT * from announce";

      $query2 = mysqli_query($db, $sql2);
      $counter = 1;
      while ($row = mysqli_fetch_array($query2)) {  ?>


        <tbody>
          
          <td><?php echo $row['news']; ?></td>
         
         </tbody>
       <?php }
           ?>

                 </tbody>
           </table>

      </div>

    

 