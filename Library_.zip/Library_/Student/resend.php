

<!DOCTYPE html>
<html>
<head>

  <title>Student Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 

  <style type="text/css">
    section
    {
      
      margin-top: -20px;
    }
    .reg{
     background-color: white; 
    }
    .box2{
      height: 850px;
      margin-top: 25px;
      padding-top: 10px;
      border-width: 3px;
  border-style: solid;
  border-color: #04AA6D;
      background-color: transparent;
      color: black;
      font-size: 15px;
    }
  </style>   
</head>
<body>
<?php 
  include "connection.php";
  include "navbar.php";
?>
<section>
  <div class="reg">

    <div class="box2">
        <h1 style="text-align: center; font-size: 30px; font-weight: bold;">Student Registration Form</h1>

      <form name="Registration" action="" method="post">
        
        <div class="login">
          <label>First Name</label>
          <input class="form-control" type="text" name="first" placeholder="First Name" required=""> <br>
          <label>Last Name</label>
          <input class="form-control" type="text" name="last" placeholder="Last Name" required=""> <br>
          <label>UserName</label>
          <input class="form-control" type="text" name="username" placeholder="Username" required=""> <br>
          <label>Password</label>
          <input class="form-control" type="password" name="password" placeholder="[a-z],[A-Z],[0-9] or specialchar and min 6 Chars" pattern="(?=^.{6,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" required=""> <br>
          <label>ID Number</label>
          <input class="form-control" type="text" name="roll" placeholder="Enter valid ID No" pattern="(ASH|BKH|MUH|BFH|BSMH)[0-9]{7}M|(ASH|BKH|MUH|BFH|BSMH)[0-9]{7}F" required=""><br>
          <label>Session</label>
          <input class="form-control" type="text" name="session" placeholder="Enter Session like 2012-2013" required="/^20[0-9]{2}-20[0-9]{2}$/"><br>
          <label for="department">Choose a department..</label>
  <select name="department" style="background-color: #B0E6B5; width: 200px; height: 25px; border-radius: 10px; border:2px solid black;">
        <optgroup label="Engineering">
          <option>Select</option>
          <option>ICE</option>
          <option>IIT</option>
          <option>ACCE</option>
          <option>AM</option>
          <option>EEE</option>
          <option>CSTE</option>
          
        </optgroup>
        <optgroup label="Biological">

          <option>BGE</option>
          <option>MB</option>
          <option>PHARMACY</option>
          <option>GE</option>
        </optgroup>
        
      </select>
      <br><br>
<label>Email</label>
<!---pattern="[a-z0-9]+@student.nstu.edu.bd"-->
          <input class="form-control" type="email" name="email" placeholder="example@student.nstu.edu.bd"  required=""><br>
          <label>Contact Number</label>
          <input class="form-control" type="text" name="contact" placeholder="01*********" pattern="01[3|4|5|6|7|8|9][0-9]{8}" required=""><br>

          <input class="btn btn-default" type="submit" name="submit" value="Sign Up" style="color: black; width: 305px; height: 40px; background-color: #F4D101; border-radius: 20px; font-weight: bold; font-size: 20px;"> </div>
      </form>
     
    </div>
  </div>
</section>

    <?php

      if(isset($_POST['submit']))
      {
        $count=0;

        $sql="SELECT username from `student`";
        $res=mysqli_query($db,$sql);

        while($row=mysqli_fetch_assoc($res))
        {
          if($row['username']==$_POST['username'])
          {
            $count=$count+1;
          }
        }
        if($count==0)
        {
          // mysqli_query($db,"INSERT INTO `student` VALUES('',$_POST[first]', '$_POST[last]', '$_POST[username]', '$_POST[password]', '$_POST[roll]', '$_POST[email]', '0', '$_POST[contact]', 'p.jpg');");
                      $first=$_POST['first'];
                      $last=$_POST['last'];
                      $username=$_POST['username'];
                      $password=$_POST['password'];
                      $roll=$_POST['roll'];
                      $session=$_POST['session'];
                      $department=$_POST['department'];
                      $email=$_POST['email'];
                      $contact=$_POST['contact'];
                      $sql="INSERT INTO `student`(`id`,`first`, `last`, `username`, `password`, `roll`,`session`,`department`, `email`, `status`, `contact`, `pic`)  VALUES(null,'$first', '$last', '$username', '$password', '$roll','$session','$department' ,'$email', '0', '$contact', 'p.jpg')";
                      $result=$db->query($sql);
          echo $db->error;
          $otp=rand(10000,99999);
          $date=date("Y-m-d");
          mysqli_query($db,"INSERT INTO verify VALUES(null,'$_POST[username]','$otp','$date');");
          $body = "Hello your OTP code is: ".$otp." .";
          $headers = "From: nabilabasher001@gmail.com";


          if (mail($_POST['email'], "OTP", $body, $headers)) 
          {
            ?>
          <script type="text/javascript">
             window.location="../verify.php"
          </script>
        <?php
          } 

          else
        {

          ?>
            <script type="text/javascript">
              alert("Your OTP is not sent");
            </script>
          <?php

        }
        }
        else
        {

          ?>
            <script type="text/javascript">
              alert("The username already exist.");
            </script>
          <?php

        }

      }

    ?>

</body>
</html>