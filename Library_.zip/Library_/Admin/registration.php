<?php
  include "connection.php";
  include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>

  <title>Admin Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 

  <style type="text/css">
    section
    {
    	padding-top: -100px;
    margin-top: -50px;
     
    }
    .reg{
    	background-color: white;

    }
    .box2{
      height: 700px;
      margin-top: 60px;
      background-color: transparent;
      color: black;
      font-size: 15px;
      border-width: 3px;
  border-style: solid;
  border-color: #04AA6D;
    }
    body{
    	background-color: white;
    }

  </style>   
</head>
<body>

<section>
  <div class="reg">

    <div class="box2">
       <br><h1 style="text-align: center; font-size: 30px; font-weight: bold;">Admin Registration Form</h1>

      <form name="Registration" action="" method="post">
        
        <div class="login">
          <label>First Name</label>
         <input class="form-control" type="text" name="first" placeholder="First Name" required=""><br>
         <label>Last Name</label>
          <input class="form-control" type="text" name="last" placeholder="Last Name" required=""> <br>
          <label>UserName</label>
          <input class="form-control" type="text" name="username" placeholder="Username" pattern="{4}" required=""> <br>
          <label>Password</label>
          <input class="form-control" type="password" name="password" placeholder="[a-z],[A-Z],[0-9] or specialchar and min 5 Chars" pattern="(?=^.{5,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"  required=""> <br>
          <label>Email</label>
          <input class="form-control" type="email" name="email" placeholder="exapmle@gmail.com" required=""><br>
          <label>Contact Number</label>
          <input class="form-control" type="text" name="contact" placeholder="01*********" pattern="01[3|4|5|6|7|8|9][0-9]{8}" required=""><br>

          <input class="btn btn-default" type="submit" name="submit" value="Sign Up" style="color: black; width: 305px; height: 40px; background-color: #F4D101; border-radius: 20px; font-weight: bold; font-size: 20px;"> <br></div>
      </form>
     
    </div>
  </div>
</section>

    <?php

      if(isset($_POST['submit']))
      {
        $count=0;
        $sql="SELECT username from `admin`";
        $res=mysqli_query($db,$sql);

        while($row=mysqli_fetch_assoc($res))
        {
          if($row['username']==$_POST['username'])
          {
            $count=$count+1;
          }
        }
        if($count==0)
        {
          mysqli_query($db,"INSERT INTO `admin` VALUES('', '$_POST[first]', '$_POST[last]', '$_POST[username]', '$_POST[password]', '$_POST[email]', '$_POST[contact]', 'p.jpg', '');");
        ?>
          <script type="text/javascript">
            alert("Your Registration are pending,If accepted inform in your mail");
            window.location="../login.php"
          </script>
        <?php
        }
        else
        {

          ?>
            <script type="text/javascript">
              alert("The username already exist.");
            </script>
          <?php

        }

      }

    ?>

</body>
</html>