
<!DOCTYPE html>
<html>
<head>

  <title>Forget pass</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/library.png">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

  <style type="text/css">
    section
    {
           margin-top: -20px;
           height: 630px;
           width: 1350px;
           background-image: url("images/reg2.jpg");
           background-repeat: no-repeat;
    }
    .box{
  height: 400px;
  width: 450px;
  background-color:transparent;
  margin: 0px auto;
  opacity: .7;
  color: black;
  padding: 20px;
  padding-top: 100px;
 

    }
    label{
      font-weight: 600;
      font-size: 18px;
      font-weight: bold;
    }
    .btn-default{
      background-color: #CF8656;
      border-color: blcak;
      margin-left: 163px;
    }
    .btn-default{
      border: 2px solid black;
      border-radius: 15px;
      padding-bottom: 30px;


    }
    .btn-default{
  transition-duration: 0.4s;
}

.btn-default:hover {
  background-color: yellow;
  color: white;
  border: 2px solid black;
}
.btn-default {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}


  </style>   
</head>
<body>
<?php 
	include "connection.php";
	include "navbar.php";
?>
<section><br><br><br><br><br><br>
  <div class="box">
     <form  name="signup" action="" method="post">
       <b><p style="padding-left: 150px; font-size: 30px; font-weight: 700px; color: yellow; font-weight: bold;">You are</p></b>
       <input style="margin-left: 100px; width: 18px;" type="radio" name="user" id="admin" value="admin">
       <label for="admin">Admin</label>
       <input  style="margin-left: 40px; width: 18px;" type="radio" name="user" id="student" value="student" checked="">
       <label for="student">Student</label><br><br>
       <button class="btn btn-default" type="submit" name="submit1" style="color: black; font-weight: 700; width: 90px; height: 30px; font-size: 18px; ">Ok</button>
     </form>
  </div>
  <?php
  if (isset($_POST['submit1'])) {
    
   if ($_POST['user']=='admin') {
   ?>
          <script type="text/javascript">
            window.location="entermail.php"
          </script>
          <?php
   }
   else{
     ?>
          <script type="text/javascript">
            window.location="enter_email.php"
          </script>
          <?php
   }
  }
  ?>
  </section>
</body>
</html>