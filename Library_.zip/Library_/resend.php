<!DOCTYPE html>
<html>
<head>

  <title>Verify Email Address</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <style type="text/css">
    section
    {
      background-color: transparent;
    
      margin-top: -20px;

    }
    .verify-form {
    width: 340px;
    margin: 50px auto;
    font-size: 15px;
}
.verify-form form {
    margin-bottom: 15px;
    background: #f7f7f7;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    padding: 30px;
}
.verify-form h2 {
    margin: 0 0 15px;
}
.form-control, .btn {
    min-height: 38px;
    border-radius: 2px;
}
.btn {        
    font-size: 15px;
    font-weight: bold;
}
  </style>   

</head>
<body>

<?php 
include "navbar.php";
include "connection.php";

?>
<section>
  <div>
   <br>
    <div class="verify-form">
        <form action="verify.php" method="post">
        <h2 class="text-center">Verify Email Address</h2> 
        <p>Please Enter Your OTP to verify your email address</p>      
  
            <button type="submit" name="submit_resend" class="btn btn-primary btn-block">Resend OTP</button>
        </div>

        
    </form>
</section>

   <?php

      if(isset($_POST['submit_resend']))
      {
        $count=0;

        $sql="SELECT username from `student`";
        $res=mysqli_query($db,$sql);

        while($row=mysqli_fetch_assoc($res))
        {
          if($row['username']==$_POST['username'])
          {
            $count=$count+1;
          }
        }
        if($count==0)
        {
          
          echo $db->error;
          $otp=rand(10000,99999);
          $date=date("Y-m-d");
          mysqli_query($db,"INSERT INTO verify VALUES(null,'$_POST[username]','$otp','$date');");
          $body = "Hello your OTP code is: ".$otp." .";
          $headers = "From: nabilabasher001@gmail.com";


          if (mail($_POST['email'], "OTP", $body, $headers)) 
          {
            ?>
          <script type="text/javascript">
             window.location="../verify.php"
          </script>
        <?php
          } 

          else
        {

          ?>
            <script type="text/javascript">
              alert("Your OTP is not sent");
            </script>
          <?php

        }
        }
        else
        {

          ?>
            <script type="text/javascript">
              alert("The username already exist.");
            </script>
          <?php

        }

      }

    ?>





 </body>
 </html>