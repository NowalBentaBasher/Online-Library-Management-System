<!DOCTYPE html>
<html>
<head>

  <title>Verify Email Address</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <style type="text/css">
    section
    {
      background-color: transparent;
    
      margin-top: -20px;

    }
    .verify-form {
    width: 340px;
    margin: 50px auto;
    font-size: 15px;
}
.verify-form form {
    margin-bottom: 15px;
    background: #f7f7f7;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    padding: 30px;
}
.verify-form h2 {
    margin: 0 0 15px;
}
.form-control, .btn {
    min-height: 38px;
    border-radius: 2px;
}
.btn {        
    font-size: 15px;
    font-weight: bold;
}
  </style>   

</head>
<body>

<?php 
include "navbar.php";
include "connection.php";

?>
<section>
  <div>
   <br>
    <div class="verify-form">
        <form action="verify.php" method="post">
        <h2 class="text-center">Verify Email Address</h2> 
        <p>Please Enter Your OTP to verify your email address</p>      
        <div class="form-group">
            <input type="text" name="OTP" class="form-control" placeholder="Enter your otp" required="required">
        </div>
        
        <div class="form-group">
            <button type="submit" name="submit_verify" class="btn btn-primary btn-block">Verify</button>
        </div>

        <div>
             <a style="color:red; text-decoration: none;font-weight: bold;" href="resend.php">Didn't get otp?</a>
        </div>
        
    </form>
</section>

 	<?php
 	$ver1=0; 
 	if (isset($_POST['submit_verify']))
 	 {
 		$ver2=mysqli_query($db,"SELECT * FROM verify;");
 		while ($row= mysqli_fetch_assoc($ver2)) 
 		{
 			if ($_POST['OTP']==$row['otp']) 
 			{
 				mysqli_query($db,"UPDATE student set status='1' where username='$row[username]';");
 				$ver1=$ver1+1;
 			}
 		}
 		if ($ver1==1) {
 			header("location:login.php");
 		}
 		else
 		{
 			?>
            <script type="text/javascript">
              alert("Wrong OTP is given. Please Try again");
            </script>
          <?php

 		}

 	}

 	 ?>
 





 </body>
 </html>